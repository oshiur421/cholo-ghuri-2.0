# Cholo Ghuri — APK Project

Cholo Ghuri web app (Biker Convoy & Highway Radar) ke Capacitor diye Android APK
bananor ready project. Web app er kono code change kora hoy nai — sudhu wrap kora
hoise, jate phone e app er moto install kore chalano jay.

- **App ID:** `com.chologhuri.app`
- **App name:** Cholo Ghuri
- **Version:** 1.0 (versionCode 1)
- **Web files:** `www/` — `index.html`, `app.js`, `style.css`, `logo.png`
- **GPS permission:** Fine + Coarse location add kora ache (`AndroidManifest.xml`)
- **Icon:** tomar `logo.png` theke banano launcher icon
- **Internet lagbe:** Mapbox map, Supabase realtime, Tailwind/Leaflet CDN — egula
  online chara cholbe na. Offline e app khulbe, kintu map ar convoy sync cholbe na.

## Option A — PC te Android Studio diye APK (sobcheye shohoj)

1. PC te [Android Studio](https://developer.android.com/studio) install koro
   (install er somoy Android SDK 35 + JDK 17 auto ashe).
2. Ei folder ta PC te nao, terminal e:
   ```bash
   cd cholo-ghuri-apk
   npm install
   npx cap sync android
   ```
3. Android Studio te `android/` folder ta khulo, opore **Build > Build App Bundle(s) /
   APK(s) > Build APK(s)** dao.
4. APK paba: `android/app/build/outputs/apk/debug/app-debug.apk`
5. APK ta phone e pathiye install koro. Install er somoy **Unknown sources / Install
   unknown apps** allow korte hobe, ar app khule **Location permission Allow** dio.

## Option B — GitHub Actions diye APK (PC te kichu install lagbe na)

1. GitHub e notun repo banao, ei folder er shob file push koro
   (`node_modules` bad diye — `.gitignore` e ache).
2. GitHub repo te **Actions** tab e jao, `Build APK` workflow ta run koro
   (push korlei auto run hobe).
3. Run sesh hole **Artifacts** theke `cholo-ghuri-debug-apk` download koro,
   vitore `app-debug.apk` thakbe.

## Option C — Muse ekhane build kore dibe

Muse app er ekta setting er jonno ekhane Gradle build atke ache. Tumi jodi
Muse app e giye **Settings -> Permissions -> Direct network protocols ->
other_tcp** — `Deny` theke `Ask` koro, tahole amake bolo, ami ekhanei APK
build kore ekhane diye dibo. Setting ta na bodlale Option A ba B use koro.

## Phone e install korar por

1. APK install koro, app khulo.
2. Location permission **Allow while using the app** dao — nahole GPS/map
   tomar location dekhabe na, Dhaka (23.8103, 90.4125) fallback dekhabe.
3. Internet on rakho, tarpor rider name + room code diye convoy te join koro.

## Release APK (Play Store er jonno)

Ekhon jeta banabe oita **debug APK** — nijer phone e install/test korar jonno.
Play Store e dite hole pore ekta signed release APK (keystore diye) banate hobe.
Tokhon amake bolo, ami release build er step diye dibo.

## File gular hisab

| File | Kaj |
| --- | --- |
| `www/` | Tomar ashol web app |
| `capacitor.config.json` | App ID, name, allowed server (Supabase/Mapbox/CDN) |
| `package.json` | Capacitor 7 + Geolocation plugin |
| `android/` | Native Android project (Capacitor theke toiri) |
| `.github/workflows/build-apk.yml` | GitHub Actions e auto APK build |
